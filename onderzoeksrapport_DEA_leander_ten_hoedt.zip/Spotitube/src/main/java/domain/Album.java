package domain;

public class Album {
    private String name;

    public Album(String name) {
        this.name = name;
    }

    public String getName() {
        return this.name;
    }
}
