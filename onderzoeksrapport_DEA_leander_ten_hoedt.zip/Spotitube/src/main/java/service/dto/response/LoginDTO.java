package service.dto.response;

public class LoginDTO {
    public String token;
    public String user;
}
