package service.dto.response;

import java.util.ArrayList;

public class TracksDTO {
    public ArrayList<TrackDTO> tracks;
}
