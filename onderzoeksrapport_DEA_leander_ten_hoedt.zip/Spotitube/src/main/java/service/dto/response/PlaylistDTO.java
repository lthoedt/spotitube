package service.dto.response;

import java.util.ArrayList;

public class PlaylistDTO {
    public String id;
    public String name;
    public Boolean owner;
    public ArrayList<TrackDTO> tracks;
}
