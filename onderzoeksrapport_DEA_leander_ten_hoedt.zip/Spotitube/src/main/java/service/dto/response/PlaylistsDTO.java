package service.dto.response;

import java.util.ArrayList;

public class PlaylistsDTO {
    public ArrayList<PlaylistDTO> playlists;
    public int length = 0;
}
