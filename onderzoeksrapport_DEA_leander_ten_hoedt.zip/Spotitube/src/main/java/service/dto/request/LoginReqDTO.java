package service.dto.request;

public class LoginReqDTO {
    public String user;
    public String password;
}
