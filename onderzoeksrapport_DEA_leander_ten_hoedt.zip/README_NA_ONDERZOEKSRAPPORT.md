bestand locaties:

Het nieuwe database create script staat in `Database/create.cypher`

Het onderzoeks rapport staat in `Docs/Onderzoeksrapport_Spotitube.docx|pdf`.

Het labonderzoek staat in `labonderzoek/labonderzoek`.

Het werkplaatsonderzoek staat in `Spotitube/`.

Waarbij onderstaande bestanden zijn aangepast

* `src/main/java/dao/TrackDAO.java`
* `src/main/java/service/utils/DB.java`
* `/pom.xml`
